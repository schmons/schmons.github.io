##################################################
# Large Sample Asymptotics of the Pseudo-Marginal Method
# 
# This script implements a artificial random effects model
# Version: 05/05/2018
# Author: Sebastian Schmon
#
# Use: run in command like "Rscript latent_variablesE.R 20" for 20 particles
##################################################

# Command line arguments
args = commandArgs(trailingOnly=TRUE)

args = as.numeric(args[1])

if (length(args)==0 || class(args[1])!="numeric") {
  stop("At least one numeric argument must be supplied (particles).\n", call.=FALSE)
} else if (length(args)==1) {
  # default output file
  cat("Running R script with", args[1], "Particles\n")
}

# Generate Data
# Simple model (correlated)
set.seed(100)
suppressMessages(library(mixtools))
theta = 0.5
n = args
X = rnorm(n, theta, 1)
Y = rnorm(n, X)

cat("Running Toy example with T = ", n, "\n")

theta_ML = mean(X)
info     = sqrt(2/n)

sigma0 = 100000

post_mean = 1/(1/sigma0^2 + n/2)*(sum(Y)/2)
cat("Posterior mean:", post_mean, "\n")
post_sigma = 1/(1/sigma0^2 + n/2)
cat("Posterior sd:", post_sigma, "\n")


mcmc <- function(beta0, length, target, y, Sigma=2) {
  suppressMessages(require(lubridate))
  
  # set timer
  time = proc.time()[3]
  
  beta   <- rep(0, length)
  S      <- rep(0, length)
  t      <- rep(0, length)
  accept <- rep(0, length-1)
  
  beta[1] <- beta0
  t[1]    <- target(beta0, y=y)
  
  for(i in 1:(length-1)) {
    
    B <- as.numeric(beta[i] + 2*rnorm(1, 0, Sigma))
    
    S[i] <- target(B, y=y)
    # cat("B = ", B, " S = ", S, "\n")
    R <- S[i] - t[i] + dnorm(B, 0, sigma0, log=TRUE) - dnorm(beta[i], 0, sigma0, log=TRUE)
    u <- runif(1)
    
    if(!is.na(R) & log(u) <= R) {
      beta[i+1] <- B
      t[i+1]       <- S[i]
      accept[i+1]  <- 1
    } else {
      beta[i+1] <- beta[i]
      t[i+1]       <- t[i]
    }
    
    #if(i %% 100 == 0) {
      td = seconds_to_period(-(length-i)/i*(time-proc.time()[3]))
      cat('\r',"Iteration: ", i, "/", length, " :::: Acceptance ratio: ", format(round(mean(accept[1:i+1]), 3), nsmall=3) , 
          " :::: ETA: ", day(td),":", td@hour,":", td@minute,":",round(second(td), 0), "         ", sep="")
      flush.console() 
    #}

  }
  
  return(list(beta=beta, t=t, S=S, accept=accept))
}

# Table for different data

if(n == 10) {
  NN = seq(1, 10, 1) # for n = 10
} else if(n == 20) {
  NN = seq(6, 12, 1) # for n = 20
} else if(n == 30) {
  NN = seq(8, 20, 1) # for n = 30
} else if(n == 50) {
  NN = seq(10, 50, 5)  # for n = 50
} else if(n == 100) {
  NN = seq(20, 100, 10)  # for n= 100 
} else if(n == 200) {
  NN = seq(80, 200, 20) # for n= 200
} else if(n == 500) {
  NN = seq(150, 500, 50) # for n = 500
} else {
  message("Number of particles not implemented: Can be 10, 20, 30, 50, 100, 200 or 500")
}


m <- rep(0, length(NN))
a <- rep(0, length(NN))
sds = rep(0, length(NN))

set.seed(123)

for(k in 1:length(NN)) {
  
  f_lik_theta_est = function(theta, y, N=NN[k]) {
    
    
    L = rep(0, length(y))
    #print(U)
    for(i in 1:length(y)) {
      U = rnorm(N)
      l = 0
      for(j in 1:N) {
        l = l + dnorm(y[i], theta + U[j], 1)
      }
      L[i] = l/N
    }
    
    return(sum(log(L)))
  }
  
  iters = 10000
  ll = rep(0, iters)
  
  for(i in 1:iters) {
    ll[i] = f_lik_theta_est(theta, Y)
    cat('\r',"Iteration: ", i, "/", iters, "   ", sep="")
  }
  sds[k] = sd(ll)
  
  test = mcmc(beta0 = rnorm(1, post_mean, sqrt(post_sigma)), length = 25*iters, target = f_lik_theta_est, y = Y, Sigma=info)#0.208)#0.444)
  
  x = test$beta
  require(mcmcse)
  Iactx1 <- mcse(x, method="obm")$se^2*length(x)/var(x)

  m[k] <- Iactx1
  a[k] = mean(test$accept)
}

out = cbind(IAT=m, Particles=NN, SD=sds, ACC=a)
print(out)

path = paste("T",n,".RData", sep="")
save.image(path)

