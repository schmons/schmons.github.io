##################################################
# Large Sample Asymptotics of the Pseudo-Marginal Method
# 
# Creats plot of the projections in the Lotka-Volterra model
# Version: 05/05/2018
# Author: Sebastian Schmon
#
# Use: save with 12 x 9 inches 
##################################################

# Need to save the data before loading this
load("N225_long.RData")

data = data.frame(thmat)
head(data)

library(scales)

cov12 <- cov(data[, 1:2])
cov13 <- cov(data[, c(1, 3)])
cov23 <- cov(data[, 2:3])
mean1 <- mean(data$th1)
mean2 <- mean(data$th2)
mean3 <- mean(data$th3)
mean12 <- c(mean1, mean2)
mean13 <- c(mean1, mean3)
mean23 <- c(mean2, mean3)

library(mixtools)
col = alpha("dodgerblue4", 0.5)
par(mfrow=c(3, 3), cex.lab=2, cex.axis=1.5, mar=c(2,3,1,1) + 0.1)
#par(mar=c(5.1,4.1,4.1,2.1)

# Plot 1, 1 ----------------------------------------


hist(data$th1, xlab="", ylab="", main="", breaks=seq(min(data$th1), max(data$th1), length=30),
     freq=FALSE, lwd=1,  col=col, border=col,yaxt='n')
box(which = "plot", lty = "solid")
mtext(expression(beta[1]),side=2,las=1,line=1, cex=1.5)
#plot(density(data$th1), lwd=2, col="skyblue4")
curve(dnorm(x, mean(data$th1), sd(data$th1)), add=TRUE, col="firebrick", lwd=2, lty=4)


# Plot 1, 2 ----------------------------------------

plot.new()

# Plot 1, 3 ----------------------------------------

plot.new()

# Plot 2, 1 ----------------------------------------
smoothScatter(data$th1, data$th2, col=alpha("dodgerblue4", 0.01), pch=20, xlab="", 
              ylab="", yaxt="n")
mtext(expression(beta[2]),side=2,las=1,line=1, cex=1.5)
#contour(kde2d(sample1[, 1], sample1[, 2]), add=TRUE, lwd=2, 
#        drawlabels=FALSE, col="skyblue4")
ellipse(mu=mean12, sigma=cov12, alpha = .005, npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=mean12, sigma=cov12, alpha = .02, npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=c(mean1, mean2), sigma=cov12, alpha = .1,  npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=c(mean1, mean2), sigma=cov12, alpha = .24, npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=c(mean1, mean2), sigma=cov12, alpha = .5,  npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=c(mean1, mean2), sigma=cov12, alpha = .8,  npoints = 250, col="firebrick", type="l", lwd=2)

# Plot 2, 2 ----------------------------------------

hist(data$th2, xlab="", ylab="", main="", breaks=seq(min(data$th2), max(data$th2), length=30),
     freq=FALSE, col=col, border=col, yaxt="n")
box(which = "plot", lty = "solid")
#plot(density(data$th1), lwd=2, col="skyblue4")
curve(dnorm(x, mean(data$th2), sd(data$th2)), add=TRUE, col="firebrick", lwd=2, lty=4)

# Plot 2, 3 ----------------------------------------

plot.new()

# Plot 3, 1 ----------------------------------------

smoothScatter(data$th1, data$th3, col=alpha("dodgerblue4", 0.01), pch=20, 
              xlab=expression(beta[1]), ylab="", yaxt="n")
mtext(expression(beta[3]),side=2,las=1,line=1, cex=1.5)
#contour(kde2d(sample1[, 1], sample1[, 2]), add=TRUE, lwd=2, 
#        drawlabels=FALSE, col="skyblue4")
ellipse(mu=mean13, sigma=cov13, alpha = .005, npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=mean13, sigma=cov13, alpha = .02, npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=c(mean1, mean3), sigma=cov13, alpha = .1,  npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=c(mean1, mean3), sigma=cov13, alpha = .24, npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=c(mean1, mean3), sigma=cov13, alpha = .5,  npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=c(mean1, mean3), sigma=cov13, alpha = .8,  npoints = 250, col="firebrick", type="l", lwd=2)

# Plot 3, 2 ----------------------------------------

smoothScatter(data$th2, data$th3, col=alpha("dodgerblue4", 0.01), pch=20, xlab=expression(beta[2]), ylab="",
              yaxt="n")
#contour(kde2d(sample1[, 1], sample1[, 2]), add=TRUE, lwd=2, 
#        drawlabels=FALSE, col="skyblue4")
ellipse(mu=mean23, sigma=cov23, alpha = .005, npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=mean23, sigma=cov23, alpha = .02, npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=mean23, sigma=cov23, alpha = .1,  npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=mean23, sigma=cov23, alpha = .24, npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=mean23, sigma=cov23, alpha = .5,  npoints = 250, col="firebrick", type="l", lwd=2)
ellipse(mu=mean23, sigma=cov23, alpha = .8,  npoints = 250, col="firebrick", type="l", lwd=2)


# Plot 3, 3 ----------------------------------------

hist(data$th3, xlab=expression(beta[3]), ylab="", main="", breaks=seq(min(data$th3), max(data$th3), length=30),
     freq=FALSE, col=col, border=col, yaxt="n")
box(which = "plot", lty = "solid")
curve(dnorm(x, mean(data$th3), sd(data$th3)), add=TRUE, col="firebrick", lwd=2, lty=4)

