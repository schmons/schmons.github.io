##################################################
# Large Sample Asymptotics of the Pseudo-Marginal Method
# 
# This script implements a lotka volterra model
# Based on code by Darren J wilkinson 
# https://darrenjw.wordpress.com/2011/11/12/particle-filtering-and-pmcmc-using-r/
# Version: 05/05/2018
# Author: Sebastian Schmon
#
# Use: run in command like "Rscript lotka_volterra 100" for 100 particles
##################################################

# Command line arguments
args = commandArgs(trailingOnly=TRUE)

args = as.numeric(args[1])


if (length(args)==0 || class(args[1])!="numeric") {
  stop("At least one numeric argument must be supplied (particles).\n", call.=FALSE)
} else if (length(args)==1) {
  # default output file
  cat("Running R script with", args[1], "Particles\n")
}

library(smfsb)
library(MASS)
suppressMessages(library(lubridate))

set.seed(16)
#set.seed(46)

# Generate data via Gillespie algorithm
length_out = 50
pp = matrix(0, 2, length_out)
th_gen = c(1,0.005,.6)

# Frequency
freq = 1

# Start
x0   = c(x1=50,x2=100)
pp[, 1] = stepLVc(x0 ,0, 1/freq, th=th_gen)

times = rep(0, length_out)

for(i in 2:length_out)
{
  times[i] = (0+i-1)/5
  pp[, i] = stepLVc(c(x1=pp[1, i-1],x2=pp[2, i-1]),(0+i-1)/freq, 1/freq, th=th_gen)
}


# Measurement errors 

noiseSD = 10
noise = matrix(rnorm(2*(length_out+1), mean=0, sd=noiseSD), 2, length_out+1)

dataLik <- function(x,t,y,log=TRUE,...)
{
  ll=sum(dnorm(y,x,noiseSD,log=TRUE))
  if (log)
    return(ll)
  else
    return(exp(ll))
}

data = cbind(x0, pp) + noise               
plot(data[1, ], type="l", lwd=3, lty=1, col="skyblue",ylim=c(0, 550), xlab="Time", ylab="Population")
points(data[1, ], pch=15)
lines(data[2, ], lwd=3, col="dodgerblue4")            

# now define a sampler for the prior on the initial state
simx0 <- function(N,t0,...)
{
  mat=cbind(rpois(N,50),rpois(N,100))
  colnames(mat)=c("x1","x2")
  mat
}

# Generate variables

iters = 250000
th=c(th1 = 1, th2 = 0.005, th3 = 0.6)
p=length(th)

ll=-1e99

thmat = matrix(0,nrow=iters,ncol=p)
llout  = matrix(0, iters, 2)

colnames(thmat)=names(th)

Sigma = matrix(c(0.00043315, 1.01e-06, 0.00010769,
                 0.00000101, 1.00e-08, 0.00000049,
                 0.00010769, 4.90e-07, 0.00017243), 3, 3)

tune = 2.17^2/3 * Sigma


# Likelihood
LVdata = as.timedData(t(data)) #ts(t(data), frequency = 5, start=0) #
colnames(LVdata)=c("x1","x2")
particles = as.numeric(args[1])

# Create function for particle filter
mLLik=pfMLLik(particles,simx0,0,stepLVc,dataLik,LVdata)

#mLLik(th_gen)

cat("Calculating noise. This may take some time...")
M = matrix(rep(th, 10000), 3, 10000)
m = apply(M, 2, mLLik)
cat("Noise level is:", sd(m), "\n")

p = 0

c = particles/length_out

cat("===============================================================")
cat("\nRunning PMCMC:\n")

time = proc.time()[3]

for (i in 1:iters) {
  
  #cat("th", th, "\n", "I", I, "\n")
  
  thprop=th + mvrnorm(n = 1, rep(0, 3), tune)
  
  llprop = mLLik(thprop) + dgamma(thprop[1], 5, 5, log=TRUE) +
    dgamma(thprop[2], 1.5, 10, log=TRUE) +
    dgamma(thprop[3], 3.5, 5, log=TRUE)   
  
  if (log(runif(1)) < llprop - ll) {
    th=thprop
    ll=llprop
    p = p+1
  }
  llout[i,]=c(ll, llprop)
  thmat[i,]=th
  
  
  td = seconds_to_period(-(iters-i)/i*(time-proc.time()[3]))
    cat('\r',"Iteration: ", i, "/", iters, " :::: Acceptance ratio: ", format(round(p/i, 3), nsmall=3) , 
        " :::: ETA: ", day(td),":", td@hour,":", td@minute,":",round(second(td), 0), "         ", sep="")
  flush.console() 
}

message("Done!")

cat("===============================================================")
cat("\nAnalysis of Particle Filter\n")

cat("Number of Particles", particles, "\n")
cat("Noise sigma:", sd(m), "\n")

cat("---------------------------------------------------------------\n")
sd_log1   = sd(llout[,1])
sd_log2   = sd(llout[,2])
cat("Stationary Likelihood sd:", sd_log1, "\n")
cat("Proposed Likelihood sd:", sd_log2, "\n\n")

cat("---------------------------------------------------------------\n")
cat("\nAnalysis of PMMH scheme for Lotka Volterra model\n")

aRate = length(unique(thmat[, 1]))/length(thmat[, 1])

cat("Chain length:", length(thmat[,1]), "samples\n\n", sep=" ")
cat("Posterior mean values\n", "a =", mean(thmat[,1]),"b =", mean(thmat[,2]), "g =", mean(thmat[,3]), "\n", sep=" ")
cat("Posterior Standard deviation\n", "a =", sd(thmat[,1]),"b =", sd(thmat[,2]), "g =", sd(thmat[,3]), "\n", sep=" ")

cat("Acceptance Rate: ", aRate,"\n")

cat("---------------------------------------------------------------\n")


# Integrated Autocorrelation Time
message("Calculating integrated autocorrelation time...",appendLF=FALSE)
suppressMessages(require(mcmcse))
Iactx1 <- mcse(thmat[, 1], method="obm")$se^2*length(thmat[, 1])/var(thmat[, 1])
Iactx2 <- mcse(thmat[, 2], method="obm")$se^2*length(thmat[, 2])/var(thmat[, 2])
Iactx3 <- mcse(thmat[, 3], method="obm")$se^2*length(thmat[, 3])/var(thmat[, 3])

cat("Integrated Autocorrelation Time\n")

cat("alpha: ", Iactx1, "\n")
cat("beta:  ", Iactx2, "\n")
cat("gamma: ", Iactx3, "\n")

cat("---------------------------------------------------------------\n")

#string = "C:/Users/sebas/Dropbox/PhD/pseudomarginal_weaklimit/R/Simulations/"
dest   = paste("N", particles, "_long.RData", sep="")

out = paste(getwd(), "/", dest, sep="")

# Uncomment to save output
#save.image(out)
cat("===============================================================")

