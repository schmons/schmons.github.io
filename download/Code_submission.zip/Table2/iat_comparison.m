% Set simulation variables
l       =  2.562;
sigma_opt = [1.16, 1.21, 1.24, 1.30, 1.44, 1.50, 1.54, 1.61, 1.74];

sigma_inf   =  1.812;
sigma_robust  =  1.2;

% Length out
K = 10;

% 5 Million 
N = 5000000;
D = [1, 2, 3, 5, 10, 15, 20, 30, 50];
I = 1;
d = D(I);
sigmas = [sigma_opt(I), sigma_robust, sigma_inf];

n1 = length(sigmas);
ct = zeros(n1, K);


parfor i = 1:n1
    
    for k = 1:K
        % Set seed
        rng(i*10+k, 'twister')
        ct(i, k) = pmcmc2(sigmas(i), l./sqrt(d), N, d)./(sigmas(i).^2);

    end

end

d
round(vertcat(mean(ct'),std(ct')), 2)




