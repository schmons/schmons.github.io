##################################################
# Large Sample Asymptotics of the Pseudo-Marginal Method
# 
# This script implements the limting pseudo-marginal algorithm
# Version: 05/05/2018
# Author: Sebastian Schmon
#
# Use: change parameters sigma, l, d, and length
##################################################


# Function definition

pmcmc_limit <- function(sigma, l, length, d) {
  
  require(MASS)
  x = matrix(0, length, d)
  print(dim(x))
  z = rep(0, length)
  p = rep(0, length-1)
  tau = rep(0, d, 1)
  
  w = rnorm(length, -sigma^2/2, sigma)
  u = runif(length)
  
  MU = rep(0, d)
  SIGMA = l^2*diag(d)
  Y     = mvrnorm(length, MU, SIGMA)
  
  # Initialise chain
  I       = diag(d);
  x[1, ]  = mvrnorm(1, MU, I)
  z[1]    = w[1] # new
  
  for(i in 2:length) {
    
    if(i %% 100000 == 0) {
      cat("Iteration: ", i, "\n")
    }    
    y      = Y[i, ] + x[i-1, ]
    R      = - sum(y^2)/2 + sum(x[i-1, ]^2)/2 + w[i] - z[i-1]
    
    if(log(u[i]) <= R) {
      
      x[i, ] = y
      z[i]   = w[i]
      p[i-1] = 1
      
    } else {
      x[i, ] = x[i-1, ]
      z[i]   = z[i-1]
    }
    
  }
  cat("Jump rate: ", round(mean(p), 4)*100, "%\n")
  return(x)
}

# Run:
set.seed(13)

sigma = 1.16
l = 2.05
length = 5000000
d = 1

x = pmcmc_limit(sigma, l/sqrt(d), length, d)
#x = test2$beta

suppressMessages(require(mcmcse))
len = length(x[1, ])
Iact = rep(0, len)

for(i in 1:len) {
  Iact[i] <- mcse(x[, i], method="obm")$se^2*length(x[, i])/var(x[, i])
  cat("Iteration:", i, "\n")
}

mean(Iact/sigma^2)
round(mean(Iact), 2)
