##################################################
# Large Sample Asymptotics of the Pseudo-Marginal Method
# 
# This script implements a real data random effects model
# Version: 05/05/2018
# Author: Sebastian Schmon
#
# Use: run in command like "Rscript glmm.R 10" for 10 particles
##################################################

# Command line arguments
args = commandArgs(trailingOnly=TRUE)

args = as.numeric(args[1])

if (length(args)==0 || class(args[1])!="numeric") {
  stop("At least one numeric argument must be supplied (particles).\n", call.=FALSE)
} else if (length(args)==1) {
  # default output file
  cat("Running R script with", args[1], "Particles\n")
}

particles = args[1]

library(mixtools)
set.seed(199)

xerop = read.table("xerop.data")

header = c("ID", "infection", "intercept", "age", "xero", "cos", "sin", "sex", "height", "stunted", "time", "baseline_age", "season", "time*time")                              
colnames(xerop) = header

formula = ~ age + xero + cos + sin + sex + height + stunted
X <- model.matrix(formula, data=xerop)
Z <- model.matrix(~ factor(xerop$ID), data=xerop)

# Define index for random effects
index = as.numeric(factor(xerop$ID))

# Estimator for marginal (log)likelihood
est_marginal_f_random <- function(y, X, theta, tau, Z, N=particles) {

  l <- max(index)
  log_W <- rep(NA, l)
  
  xb <- X%*%theta
  
  for(t in 1:l){
    index_mask <- index==t
    y_t <- y[index_mask]
    J_t <- length(y_t)
    
    mu_t <- xb[index_mask]
    
    X_t_re <- rnorm(N,0,sqrt(tau))
    X_t_re_rep <- matrix(rep(X_t_re,each=J_t),nrow=J_t)
    
    eta_t <- X_t_re_rep + mu_t
    
    e <- exp(eta_t)
    p <- e/(1+e)
    ll_t <- y_t*log(p) + (1-y_t)*log(1-p)
    
    ll_t_collapsed <- colSums(ll_t)
    max_ll <- max(ll_t_collapsed)
    
    log_W[t] <- log(mean(exp(ll_t_collapsed-max_ll))) + max_ll
  }
  
  f_theta <- sum(log_W)
  return(f_theta)
}

betas = c( -2.7879, -0.0354,  0.5646, -0.6125, -0.1748, -0.4613, -0.0521,  0.1912,  0.9401)

Sigma = matrix(c( 0.05301,  0.00031, -0.02114,  0.01484,  0.01033, -0.02522, -0.00093, -0.03498, -0.03895,
                  0.00031,  0.00006, -0.00041,  0.00000,  0.00008,  0.00009,  0.00006, -0.00038, -0.00033,
                 -0.02114, -0.00041,  0.25822, -0.00937, -0.00555,  0.01054,  0.00002, -0.00669, -0.01001,
                  0.01484,  0.00000, -0.00937,  0.03129,  0.00679, -0.00009,  0.00021,  0.00476, -0.00354,
                  0.01033,  0.00008, -0.00555,  0.00679,  0.03202, -0.00082,  0.00033,  0.00022, -0.00050,
                 -0.02522,  0.00009,  0.01054, -0.00009, -0.00082,  0.07600,  0.00033, -0.00031, -0.00734,
                 -0.00093,  0.00006,  0.00002,  0.00021,  0.00033,  0.00033,  0.00078,  0.00703, -0.00089,
                 -0.03498, -0.00038, -0.00669,  0.00476,  0.00022, -0.00031,  0.00703,  0.21642,  0.00877,
                 -0.03895, -0.00033, -0.01001, -0.00354, -0.00050, -0.00734, -0.00089,  0.00877,  0.13604), 9, 9)

time = proc.time()[3]
iters = 10000
p = rep(0, iters)
for(i in 1:iters) {
  p[i] = est_marginal_f_random(xerop$infection, X=X, theta=betas[1:8], tau=betas[9], Z, N=particles)
  
  cat("\r", "Estimating sd of noise ::: Progress: ", i, "/", iters, "       ")
}
mean(p)
sd(p)
proc.time()[3] - time
#true_target_f(xerop_small$infection, data=X, theta=betas)

# Design pseudo-marginal algorithm
pmcmc <- function(beta0, length, target, X, y,...) {
  require(lubridate)
  require("invgamma")
  # set timer
  time = proc.time()[3]
  
  betas  <- matrix(0, length, length(beta0))
  S      <- rep(0, length)
  
  d = length(beta0)
  t <- rep(0, length)
  
  betas[1, ] <- beta0
  t[1]       <- target(theta=beta0[1:8], tau=beta0[9], y=y, X=X, Z, ...) + logdmvnorm(beta0[1:8], rep(0, 8), diag(rep(10000, 8))) + dinvgamma(beta0[9], 1, 1.5, log=TRUE) 
  
  accept <- rep(0, length)
  
  W = rmvnorm(length, rep(0, d), Sigma)
  u = runif(length)

  for(i in 2:length) {
    
    B <- betas[i-1,] + 2.2/sqrt(9)*W[i, ]
    if(B[9] <= 0) {
      R <- -Inf 

    } else {
      S[i] <- target(theta=B[1:8], tau=B[9], y=y, X=X, Z, ...)
      
      R <- S[i] - t[i-1]  + logdmvnorm(B[1:8], rep(0, 8), diag(rep(10000, 8))) - logdmvnorm(betas[i-1,1:8], rep(0, 8),  diag(rep(10000, 8))) + dinvgamma(B[9], 1, 1.5, log=TRUE) - dinvgamma(betas[i-1, 9], 1, 1.5, log=TRUE) #+ dnorm(B[9], 0, 1/2, log=TRUE) - dnorm(betas[i, 9], 0, 1/2, log=TRUE)
    }

    if(log(u[i]) <= R) {
      betas[i,] <- B
      t[i]       <- S[i]
      accept[i] <- 1
    } else {
      betas[i,] <- betas[i-1,]
      t[i]       <- t[i-1]
    }
  
    if(i %% 10 == 0) {
    td = seconds_to_period(-(length-i)/i*(time-proc.time()[3]))
    cat('\r',"Iteration: ", i, "/", length, " :::: Acceptance ratio: ", format(round(mean(accept[1:i]), 3), nsmall=3) , 
        " :::: ETA: ", day(td),":", td@hour,":", td@minute,":",round(second(td), 0), "   ", sep="")
    flush.console() 
  
    }
  }
  
  return(list(beta=betas, t=t, S=S, accept=accept))
}

iterations <- 1000000

set.seed(100)
test2 <- pmcmc(beta0=betas, X=X, y=xerop$infection, length=iterations, target=est_marginal_f_random)

path = paste("RE_", particles, ".RData", sep="")
save.image(path)

x = test2$beta

library(mcmcse)
len = 9
Iact = rep(0, len)
for(i in 1:len) {
  Iact[i] <- mcse(x[, i], method="obm")$se^2*length(x[, i])/var(x[, i])
  cat("Iteration:", i, "\n")
}
Iactx1 <- mean(Iact)
acc = test2$accept
round_acc = round(mean(acc), 4)*100
round_iact = round(Iactx1, 2)
cat("Acceptance Rate is: ", round_acc, "\n")
cat("Integrated autocorrelation time is", round_iact, "\n")
