function [ IAT, p_jump ] = pmcmc2(sigma, l, length, d)
% MCMC sampler for multivariate normal target

    x    = zeros(length, d);
    z    = zeros(length, 1);
    p    = zeros(length-1, 1);
    tau  = zeros(d, 1);
    
    w    = normrnd(-sigma.^2/2, sigma, 1, length);
    u    = unifrnd(0, 1, 1, length);
    
    MU    = zeros(d, 1);
    SIGMA = l^2.*eye(d);
    Y     = mvnrnd(MU, SIGMA, length);
    
    % Initialise chain
    I       = eye(d);
    x(1, :) = mvnrnd(MU, I, 1);
    z(1)    = w(1);
    
    for i = 2:length 
        
        y      = Y(i, :) + x(i-1, :);
        R      = - norm(y)^2/2 + norm(x(i-1, :))^2/2 + w(i) - z(i-1);
        
        if(log(u(i)) <= R)
            
            x(i, :) = y;
            z(i)    = w(i);
            p(i-1)  = 1;
           
        else 
            
            x(i, :) = x(i-1, :);
            z(i)    = z(i-1);
            
        end
        
    end
    
    p_jump = mean(p);
    
    for i = 1:d
        
        tau(i) = iat2(x(:, i));
        
    end
    
    IAT    = mean(tau);
end

