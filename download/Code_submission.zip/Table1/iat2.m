function [ tau ] = iat2( x )
%iat Function for estimating the integrated autocorrelation time.

n = length(x);
v = var(x);

b = floor(sqrt(n));
%a = floor(n/b);

a = n - b + 1;

y = zeros(1, a);

for k=1:a
    y(k) = mean(x(k:(k + b - 1))); 
end 
    
muhat  = mean(x);
varhat = n * b * sum((y - muhat).^2)./(a - 1)./a;
% se      = sqrt(var.hat./n);

tau     = varhat./v;

end
   