%Set simulation variables
% d = 50
% sigma = 1.4:0.1:2;
% l = 2.2:0.1:2.8;

% d = 30
% sigma = 1.4:0.1:2;
% l = 2.2:0.1:2.8;

% d = 20
% sigma = 1.4:0.1:2;
% l = 1.9:0.1:2.6;

% d = 15
% sigma = 1.4:0.1:2;
% l = 1.9:0.1:2.6;

% d = 10
% sigma = 1:0.1:1.9;
% l = 2:0.1:2.7;

d = 5
sigma = 1:0.1:1.9;
l = 2:0.1:2.7;

% d = 3
% sigma = 1:0.1:1.9;
% l = 2:0.1:2.7;

% d = 2
% sigma = 1:0.1:1.7;
% l = 1.8:0.1:2.7;

% d = 1
% sigma = 1:0.1:1.7;
% l = 1.8:0.1:2.7;

% 5 Million
N = 5000000;

n1 = length(sigma);
n2 = length(l);
    
% Set seed
rng(20, 'twister')
K = 10;


sigma_est = zeros(1, K);
l_est     = sigma_est;

ct_sum    = zeros(n1, n2);

for k = 1:K 
    

    ct = zeros(n1, n2);
    
    for i = 1:n1
        
        s = sigma(i);
        
        parfor j = 1:n2
            
            str=strcat(num2str(i),num2str(j),num2str(k));
            result = str2double(str);
            
            rng(result, 'twister')
            ct(i, j) = pmcmc2(s, l(j)./sqrt(d), N, d)./(s.^2);
            
        end
    end
    
    [M, I] = min(ct);
    [m, j] = min(M);
    i = I(j);
    % Sigma first component
    sigma_est(k) = sigma(i)
    % l second component
    l_est(k) = l(j)
    
    ct_sum = ct_sum + ct;

end

% Dimension
d
% Mean of minimizer of sigma
mean(sigma_est)
% Standard deviation of minimizer
std(sigma_est)
% Mean of minimizer of l
mean(l_est)
% Standard deviation of minimizer
std(l_est)

ct_mean = ct_sum./K

[M, I] = min(ct_mean);
[m, j] = min(M);
i = I(j);
% Sigma first component
sigma(i)
% l second component
l(j)
